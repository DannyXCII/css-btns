$('#btns-nav .btns-button').on("click", function (){
  $('#btns-nav .btns-active').removeClass('btns-active');
  $(this).addClass('btns-active');
})

$('#btns-nav-2 .btns-button').on('click', function(){
  $('#btns-nav-2 .btns-active').removeClass('btns-active');
  $(this).addClass('btns-active');
})
